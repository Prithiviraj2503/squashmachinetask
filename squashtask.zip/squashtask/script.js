function validatePersonalDet(){

var fullname = document.getElementById("fullname").value;
var country=document.getElementById("country").value;
var state=document.getElementById("state").value;
var phone=document.getElementById("phone").value;

if(fullname.length == ''){
    nameError = true;
    document.getElementById("fullnamecheck").style.display = "block";
}else{
     nameError = false;
     document.getElementById("fullnamecheck").style.display = "none";
}
if(phone.length == ''){
    phoneError = true;
    document.getElementById("phonecheck").style.display = "block";
}else{
     phoneError = false;
     document.getElementById("phonecheck").style.display = "none";
}
if(state.length == ''){
    stateError = true;
    document.getElementById("statecheck").style.display = "block";
}else{
     stateError = false;
     document.getElementById("statecheck").style.display = "none";
}
if(country.length == ''){
    countryError = true;
    document.getElementById("countrycheck").style.display = "block";
}else{
     countryError = false;
     document.getElementById("countrycheck").style.display = "none";
}

if(nameError == false && phoneError == false && stateError == false && countryError == false){
     document.getElementById("page1ok").innerHTML = '&#10003';
     document.getElementById("page2").click();
     document.getElementById("personaldetails").style.display = "none";
     document.getElementById("companydetails").style.display = "block";
}else{
     return false;
}
}

function validateCompanyDet(){

     var companyname = document.getElementById("companyname").value;
     var emailid=document.getElementById("emailid").value;
     var jobtitle=document.getElementById("jobtitle").value;
     var yoe=document.getElementById("yoe").value;

     if(companyname.length == ''){
          companynameError = true;
          document.getElementById("companynamecheck").style.display = "block";
     }else{
          companynameError = false;
          document.getElementById("companynamecheck").style.display = "none";
     }

     if(emailid.length == ''){
          emailidError = true;
          document.getElementById("emailidcheck").style.display = "block";
     }else{
          emailidError = false;
          document.getElementById("emailidcheck").style.display = "none";
     }

     if(jobtitle.length == ''){
          jobtitleError = true;
          document.getElementById("jobtitlecheck").style.display = "block";
    }else{
          jobtitleError = false;
          document.getElementById("jobtitlecheck").style.display = "none";
     }

     if(yoe.length == ''){
          yoeError = true;
          document.getElementById("yoecheck").style.display = "block";
    }else{
          yoeError = false;
          document.getElementById("yoecheck").style.display = "none";
     }

     if(companynameError == false && emailidError == false && jobtitleError == false && yoeError == false){
          alert("Please Note Your OTP is : ***12345***. Do not share with anyone!")
          document.getElementById("page2ok").innerHTML = '&#10003';
          document.getElementById("page3").click();
          document.getElementById("companydetails").style.display = "none";
          document.getElementById("emailverification").style.display = "block";
     }else{
          return false;
     }
     
}

function backPersonal(){
     document.getElementById("personaldetails").style.display = "block";
     document.getElementById("companydetails").style.display = "none";
}
function backCompany(){
     document.getElementById("companydetails").style.display = "block";
     document.getElementById("emailverification").style.display = "none";
}


function enableGo(obj){
     if(obj.checked){
          document.getElementById("nextbtn2").disabled = false;
     }else{
          document.getElementById("nextbtn2").disabled = true;
     }
}

function GetIn(){
     otparray = [];
     var otp = document.getElementsByName("otp");
     for(i=0; i< otp.length; i++){
          otparray.push((otp[i].value));
     }
     if(otparray.toString() == '1,2,3,4,5')
     {
          document.getElementById("page3ok").innerHTML = '&#10003';
          document.getElementById("page3ok").style.backgroundColor = 'rgb(24, 6, 90)';
          document.getElementById("welcomeuser").style.display = "block";
          document.getElementById("emailverification").style.display = "none";
          var fullname = document.getElementById("fullname").value;
          document.getElementById("username").innerHTML = fullname;
     }else{
          alert("Please Ente The Valid OTP");
          return false;
     }
}
